/* This "util" library is supposed to be easy to integrate in other
   projects. This file is supposed to contain "project-specific" code,
   which is to be included by every util source file. */
#include <poldi.h>
